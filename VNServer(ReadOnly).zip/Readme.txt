This small project is intended for people who want to have a Visual Novel chat experience.

The developer of this program is not responsible for any other folders, files, media and images (and etc..) added
by other Users, that means any copyright protected materials are within the User's responsebility.

The program was originally delievered ( https://github.com/RoosterFlex/Visual-Chatting ) with example folders 
and example transparent images, which do not have any materialistic content.

Credits for the included code for networking: https://github.com/BrandonPotter/SimpleTCP

----------------------------------------------------------------------------------------------------------------------------
Client:

Tutorial for creating characters:

1. Make sure your .exe is in the same file directory as the folders Backgrounds, Characters 
   and the dll file SimpleTCP.dll .
2. In Background/background.png you can insert your own background image.
3. Every new Character can be made in Characters/[folder-name]. The Folder's name under Characters/ will be the
   character's name you will see in the program. Every image-file inserted into that folder Characters/[name]/
   will be available as an option to be shown after typing a message.
4. Make sure your other clients get the same directory with the same files. Every file is Client-sided,
   but the server will call your file by the same name, no matter which content there was put in.

Hint: Every image should have an aspect ratio of 2:1. Your image will stretch otherwise.
      Accepted image files are .png and .gif .

----------------------------------------------------------------------------------------------------------------------------
Server:

Tutorial for hosting:

1. Port forward. You will need atleast the TCP protocoll in order for it to work. If you don't know how to port
   forward, google for any tutorials.
2. Locate your IPV4. You can find it easily by pressing the windows key and typing in "CMD".
   Type in your command prompt the command: ipconfig
   You should be able to see your IPV4 now. Type that into your "Host IP" box.
   (DO NOT SHARE YOUR IP TO STRANGERS! OPENING PORT MAKES YOU EASILY A TARGET FOR HACK/VIRUS ATTACKS!)
3. Type in your port forwarded Port into the "Port" box. 
   (If you use any programs, you can just choose a non-occupied port.)
4. Locate your external IP-Adress: Find a website which displays it and give that to your friends to connect.
   Example: https://whatismyipaddress.com/
   (DO NOT SHARE YOUR IP TO STRANGERS! OPENING PORT MAKES YOU EASILY A TARGET FOR HACK/VIRUS ATTACKS!)
4.1 If you use any other programs (and not port forward) for hosting, give that IP to your friends instead.