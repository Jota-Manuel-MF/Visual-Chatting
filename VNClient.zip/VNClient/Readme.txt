This small project is intended for people who want to have a Visual Novel chat experience.

The developer of this program is not responsible for any other folders, files, media and images (and etc..) added
by other Users, that means any copyright protected materials are within the User's responsebility.

The program was originally delievered ( https://github.com/RoosterFlex/Visual-Chatting ) with example folders 
and example transparent images, which do not have any materialistic content.

Credits for the included code for networking: https://github.com/BrandonPotter/SimpleTCP

----------------------------------------------------------------------------------------------------------------------------

Tutorial for creating characters:

1. Make sure your .exe is in the same file directory as the folders Backgrounds, Characters 
   and the dll file SimpleTCP.dll .
2. In Background/background.png you can insert your own background image.
3. Every new Character can be made in Characters/[folder-name]. The Folder's name under Characters/ will be the
   character's name you will see in the program. Every image-file inserted into that folder Characters/[name]/
   will be available as an option to be shown after typing a message.
4. Make sure your other clients get the same directory with the same files. Every file is Client-sided,
   but the server will call your file by the same name, no matter which content there was put in.

Hint: Every image should have an aspect ratio of 2:1. Your image will stretch otherwise.